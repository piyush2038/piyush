# university-management-system
website belong to university management system  with different attractive web pages with the help of HTML,CSS,JAVASCRIPT..
pages are interconnected with each other with different functionality.
